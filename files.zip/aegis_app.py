"""
Aegis: Adversarial Stress Testing & Tail Risk Intelligence Platform
Full Production-Ready Streamlit Application
Made by Sourish Dey
"""

import streamlit as st
import numpy as np
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import yfinance as yf
from datetime import datetime, timedelta
from scipy import stats
from scipy.stats import norm, kurtosis, skew
import warnings
warnings.filterwarnings('ignore')

# ─── PAGE CONFIG ─────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Aegis Risk Lab",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ─── CUSTOM CSS ──────────────────────────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;0,9..40,600;0,9..40,700;1,9..40,300&family=DM+Mono:wght@300;400;500&display=swap');

/* ── Root Variables ── */
:root {
    --bg-primary: #FAFAFA;
    --bg-secondary: #F4F6F9;
    --bg-card: #FFFFFF;
    --bg-panel: #F0F3F8;
    --border-color: #E2E8F0;
    --border-accent: #C8D8F0;
    --text-primary: #0D1B2A;
    --text-secondary: #4A5568;
    --text-muted: #718096;
    --accent-blue: #1A56DB;
    --accent-navy: #0F3460;
    --accent-teal: #0EA5E9;
    --accent-red: #DC2626;
    --accent-amber: #D97706;
    --accent-green: #059669;
    --accent-purple: #7C3AED;
    --shadow-sm: 0 1px 3px rgba(0,0,0,0.08), 0 1px 2px rgba(0,0,0,0.04);
    --shadow-md: 0 4px 16px rgba(0,0,0,0.08), 0 2px 6px rgba(0,0,0,0.04);
    --shadow-lg: 0 10px 40px rgba(0,0,0,0.10), 0 4px 12px rgba(0,0,0,0.06);
    --radius: 12px;
    --radius-sm: 8px;
}

/* ── Global Reset ── */
html, body, [class*="css"] {
    font-family: 'DM Sans', -apple-system, sans-serif !important;
    background-color: var(--bg-primary) !important;
    color: var(--text-primary) !important;
}

.stApp {
    background: linear-gradient(145deg, #F0F4FF 0%, #FAFAFA 40%, #F5F0FF 100%) !important;
}

/* ── Navbar ── */
.aegis-navbar {
    position: sticky;
    top: 0;
    z-index: 999;
    background: rgba(255,255,255,0.92);
    backdrop-filter: blur(20px);
    -webkit-backdrop-filter: blur(20px);
    border-bottom: 1px solid var(--border-color);
    padding: 14px 32px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    box-shadow: var(--shadow-sm);
    margin-bottom: 28px;
}
.aegis-navbar-brand {
    display: flex;
    align-items: center;
    gap: 12px;
}
.aegis-logo {
    width: 38px;
    height: 38px;
    background: linear-gradient(135deg, #0F3460 0%, #1A56DB 50%, #7C3AED 100%);
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 18px;
    box-shadow: 0 4px 12px rgba(26,86,219,0.30);
}
.aegis-brand-text {
    font-size: 20px;
    font-weight: 700;
    letter-spacing: -0.5px;
    background: linear-gradient(135deg, #0F3460, #1A56DB);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}
.aegis-nav-links {
    display: flex;
    gap: 28px;
    font-size: 13px;
    font-weight: 500;
    color: var(--text-secondary);
}
.aegis-status {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 12px;
    font-weight: 500;
    color: var(--text-secondary);
}
.aegis-status-dot {
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: #059669;
    box-shadow: 0 0 0 3px rgba(5,150,105,0.2);
    animation: pulse 2s infinite;
}
@keyframes pulse {
    0%, 100% { box-shadow: 0 0 0 3px rgba(5,150,105,0.2); }
    50% { box-shadow: 0 0 0 6px rgba(5,150,105,0.1); }
}

/* ── Section Headers ── */
.section-header {
    margin: 36px 0 20px 0;
    padding-bottom: 14px;
    border-bottom: 1px solid var(--border-color);
}
.section-tag {
    font-size: 10px;
    font-weight: 600;
    letter-spacing: 2px;
    text-transform: uppercase;
    color: var(--accent-blue);
    margin-bottom: 6px;
}
.section-title {
    font-size: 22px;
    font-weight: 700;
    letter-spacing: -0.5px;
    color: var(--text-primary);
}
.section-subtitle {
    font-size: 13px;
    color: var(--text-muted);
    margin-top: 4px;
}

/* ── KPI Cards ── */
.kpi-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
    gap: 16px;
    margin: 20px 0;
}
.kpi-card {
    background: var(--bg-card);
    border: 1px solid var(--border-color);
    border-radius: var(--radius);
    padding: 20px;
    box-shadow: var(--shadow-sm);
    transition: all 0.2s ease;
    position: relative;
    overflow: hidden;
}
.kpi-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 3px;
    background: linear-gradient(90deg, var(--accent-blue), var(--accent-purple));
}
.kpi-card:hover {
    transform: translateY(-2px);
    box-shadow: var(--shadow-md);
}
.kpi-label {
    font-size: 11px;
    font-weight: 600;
    letter-spacing: 1px;
    text-transform: uppercase;
    color: var(--text-muted);
    margin-bottom: 10px;
}
.kpi-value {
    font-size: 28px;
    font-weight: 700;
    letter-spacing: -1px;
    font-family: 'DM Mono', monospace;
    color: var(--text-primary);
}
.kpi-sub {
    font-size: 12px;
    color: var(--text-muted);
    margin-top: 6px;
}
.kpi-badge {
    display: inline-block;
    padding: 2px 8px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 600;
    margin-top: 8px;
}
.badge-red { background: #FEF2F2; color: var(--accent-red); }
.badge-green { background: #F0FDF4; color: var(--accent-green); }
.badge-amber { background: #FFFBEB; color: var(--accent-amber); }
.badge-blue { background: #EFF6FF; color: var(--accent-blue); }

/* ── Glass Panel ── */
.glass-panel {
    background: rgba(255,255,255,0.85);
    backdrop-filter: blur(12px);
    border: 1px solid rgba(255,255,255,0.8);
    border-radius: var(--radius);
    padding: 24px;
    box-shadow: var(--shadow-md);
    margin-bottom: 20px;
}

/* ── Info Box ── */
.info-box {
    background: linear-gradient(135deg, #EFF6FF, #F5F3FF);
    border: 1px solid #C7D2FE;
    border-left: 4px solid var(--accent-blue);
    border-radius: var(--radius-sm);
    padding: 14px 18px;
    margin: 16px 0;
}
.info-box-title {
    font-size: 12px;
    font-weight: 700;
    letter-spacing: 0.5px;
    color: var(--accent-navy);
    margin-bottom: 4px;
}
.info-box-text {
    font-size: 13px;
    color: var(--text-secondary);
    line-height: 1.6;
}

/* ── Warning Box ── */
.warn-box {
    background: #FFFBEB;
    border: 1px solid #FDE68A;
    border-left: 4px solid var(--accent-amber);
    border-radius: var(--radius-sm);
    padding: 12px 16px;
    margin: 12px 0;
    font-size: 13px;
    color: #92400E;
}

/* ── Metric Row ── */
.metric-row {
    display: flex;
    gap: 16px;
    flex-wrap: wrap;
    margin: 12px 0;
}
.metric-chip {
    background: var(--bg-panel);
    border: 1px solid var(--border-color);
    border-radius: 8px;
    padding: 10px 16px;
    display: flex;
    flex-direction: column;
    gap: 2px;
    min-width: 120px;
}
.metric-chip-label { font-size: 11px; color: var(--text-muted); font-weight: 500; }
.metric-chip-val { font-size: 16px; font-weight: 700; font-family: 'DM Mono', monospace; }

/* ── Table ── */
.styled-table {
    width: 100%;
    border-collapse: separate;
    border-spacing: 0;
    font-size: 13px;
}
.styled-table th {
    background: var(--bg-panel);
    color: var(--text-muted);
    font-size: 11px;
    font-weight: 600;
    letter-spacing: 0.8px;
    text-transform: uppercase;
    padding: 10px 14px;
    text-align: left;
    border-bottom: 1px solid var(--border-color);
}
.styled-table td {
    padding: 10px 14px;
    border-bottom: 1px solid var(--border-color);
    font-family: 'DM Mono', monospace;
}
.styled-table tr:last-child td { border-bottom: none; }

/* ── Regime Badge ── */
.regime-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 4px 12px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 600;
}
.regime-crisis { background: #FEF2F2; color: #991B1B; border: 1px solid #FECACA; }
.regime-stress { background: #FFFBEB; color: #92400E; border: 1px solid #FDE68A; }
.regime-normal { background: #F0FDF4; color: #065F46; border: 1px solid #A7F3D0; }
.regime-bull   { background: #EFF6FF; color: #1E40AF; border: 1px solid #BFDBFE; }

/* ── Footer ── */
.aegis-footer {
    text-align: center;
    padding: 40px 20px 20px;
    margin-top: 60px;
    border-top: 1px solid var(--border-color);
    color: var(--text-muted);
    font-size: 13px;
}
.aegis-footer-brand {
    font-size: 15px;
    font-weight: 700;
    background: linear-gradient(135deg, #0F3460, #1A56DB);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    margin-bottom: 6px;
}
.aegis-footer-made {
    font-size: 12px;
    opacity: 0.7;
    letter-spacing: 0.5px;
}

/* ── Streamlit overrides ── */
.stButton > button {
    background: linear-gradient(135deg, #0F3460, #1A56DB) !important;
    color: white !important;
    border: none !important;
    border-radius: var(--radius-sm) !important;
    padding: 10px 24px !important;
    font-weight: 600 !important;
    font-size: 14px !important;
    letter-spacing: 0.3px !important;
    transition: all 0.2s ease !important;
    box-shadow: 0 4px 12px rgba(26,86,219,0.25) !important;
}
.stButton > button:hover {
    transform: translateY(-1px) !important;
    box-shadow: 0 6px 20px rgba(26,86,219,0.35) !important;
}
[data-testid="stSidebar"] {
    background: linear-gradient(180deg, #0D1B2A 0%, #0F3460 100%) !important;
    border-right: 1px solid rgba(255,255,255,0.08) !important;
}
[data-testid="stSidebar"] * {
    color: rgba(255,255,255,0.85) !important;
}
[data-testid="stSidebar"] .stSelectbox label,
[data-testid="stSidebar"] .stSlider label,
[data-testid="stSidebar"] .stMultiSelect label {
    color: rgba(255,255,255,0.65) !important;
    font-size: 12px !important;
    font-weight: 500 !important;
    letter-spacing: 0.5px !important;
}
[data-testid="stSidebar"] .stSelectbox > div > div {
    background: rgba(255,255,255,0.08) !important;
    border: 1px solid rgba(255,255,255,0.15) !important;
    color: white !important;
}
[data-testid="stSidebar"] .stSlider > div > div > div {
    background: #1A56DB !important;
}
[data-testid="stSidebar"] hr {
    border-color: rgba(255,255,255,0.1) !important;
}

div[data-testid="stMetric"] {
    background: var(--bg-card);
    border: 1px solid var(--border-color);
    border-radius: var(--radius-sm);
    padding: 16px;
    box-shadow: var(--shadow-sm);
}
div[data-testid="stMetricValue"] {
    font-family: 'DM Mono', monospace !important;
    font-size: 24px !important;
}

.stTabs [data-baseweb="tab-list"] {
    background: var(--bg-panel) !important;
    border-radius: var(--radius-sm) !important;
    padding: 4px !important;
    border: 1px solid var(--border-color) !important;
}
.stTabs [data-baseweb="tab"] {
    border-radius: 6px !important;
    font-size: 13px !important;
    font-weight: 500 !important;
    color: var(--text-secondary) !important;
}
.stTabs [aria-selected="true"] {
    background: var(--accent-blue) !important;
    color: white !important;
}

.stExpander {
    border: 1px solid var(--border-color) !important;
    border-radius: var(--radius-sm) !important;
}
</style>
""", unsafe_allow_html=True)


# ─── NAVBAR ─────────────────────────────────────────────────────────────────
st.markdown("""
<div class="aegis-navbar">
    <div class="aegis-navbar-brand">
        <div class="aegis-logo">🛡️</div>
        <span class="aegis-brand-text">Aegis Risk Lab</span>
    </div>
    <div class="aegis-nav-links">
        <span>Data Engine</span>
        <span>Scenario Generator</span>
        <span>Simulation</span>
        <span>Analytics</span>
        <span>Export</span>
    </div>
    <div class="aegis-status">
        <div class="aegis-status-dot"></div>
        <span>System Online</span>
    </div>
</div>
""", unsafe_allow_html=True)


# ─── HELPERS & ENGINES ───────────────────────────────────────────────────────

@st.cache_data(ttl=300, show_spinner=False)
def fetch_data(tickers: list, period: str = "2y") -> pd.DataFrame:
    """Fetch historical OHLCV data from Yahoo Finance."""
    frames = {}
    for tkr in tickers:
        try:
            df = yf.download(tkr, period=period, auto_adjust=True, progress=False)
            if not df.empty:
                frames[tkr] = df["Close"].squeeze()
        except Exception:
            pass
    if not frames:
        return pd.DataFrame()
    prices = pd.DataFrame(frames).dropna(how="all")
    prices.ffill(inplace=True)
    prices.bfill(inplace=True)
    return prices


@st.cache_data(ttl=60, show_spinner=False)
def fetch_live_quote(ticker: str) -> dict:
    """Fetch live quote data."""
    try:
        t = yf.Ticker(ticker)
        info = t.fast_info
        hist = t.history(period="2d")
        price = float(hist["Close"].iloc[-1]) if not hist.empty else 0.0
        prev  = float(hist["Close"].iloc[-2]) if len(hist) > 1 else price
        chg   = (price - prev) / prev * 100 if prev else 0.0
        return {"price": price, "change_pct": chg, "ticker": ticker}
    except Exception:
        return {"price": 0.0, "change_pct": 0.0, "ticker": ticker}


def compute_returns(prices: pd.DataFrame, log: bool = True) -> pd.DataFrame:
    if log:
        return np.log(prices / prices.shift(1)).dropna()
    return prices.pct_change().dropna()


def detect_regime(returns: pd.Series, window: int = 20) -> pd.Series:
    """Rolling vol-based regime: bull/normal/stress/crisis."""
    ann_vol = returns.rolling(window).std() * np.sqrt(252)
    q25, q50, q75 = ann_vol.quantile(0.25), ann_vol.quantile(0.50), ann_vol.quantile(0.75)
    def label(v):
        if pd.isna(v): return "Unknown"
        if v < q25: return "Bull"
        if v < q50: return "Normal"
        if v < q75: return "Stress"
        return "Crisis"
    return ann_vol.map(label)


def block_bootstrap(returns: np.ndarray, n_scenarios: int, horizon: int, block_size: int = 10) -> np.ndarray:
    """Block bootstrap to preserve autocorrelation / vol clustering."""
    T = len(returns)
    scenarios = np.zeros((n_scenarios, horizon))
    for i in range(n_scenarios):
        path = []
        while len(path) < horizon:
            start = np.random.randint(0, max(1, T - block_size))
            block = returns[start: start + block_size]
            path.extend(block.tolist())
        scenarios[i] = np.array(path[:horizon])
    return scenarios


def vae_generate(returns: np.ndarray, n_scenarios: int, horizon: int,
                  tail_amplify: float = 1.0) -> np.ndarray:
    """
    Lightweight VAE-style generative model.
    Encodes returns via moment-matching, samples from learned distribution,
    and applies fat-tail augmentation.
    """
    mu     = np.mean(returns)
    sigma  = np.std(returns)
    kurt   = float(kurtosis(returns, fisher=False))
    sk     = float(skew(returns))
    df_t   = max(3.0, 6.0 / max(kurt - 3, 0.01))  # match excess kurtosis via Student-t

    # Sample from Student-t (fat tails) and skew via skew-normal mixture
    t_samples = stats.t.rvs(df=df_t, size=(n_scenarios, horizon)) * sigma + mu
    # Skew adjustment
    skew_adj  = sk * sigma * 0.1
    noise     = np.random.randn(n_scenarios, horizon) * sigma * 0.15
    scenarios = t_samples + skew_adj + noise

    # Tail amplification
    if tail_amplify > 1.0:
        bottom_mask = scenarios < np.percentile(scenarios, 5)
        scenarios[bottom_mask] *= tail_amplify

    return scenarios


def apply_adversarial_perturbations(scenarios: np.ndarray,
                                     vol_shock: float,
                                     drift_shift: float,
                                     correlation_crush: float) -> np.ndarray:
    """Apply adversarial modifications to scenario paths."""
    out = scenarios.copy()
    sigma = np.std(scenarios)
    # Vol shock: multiply extreme tails
    shock_mask = np.abs(out) > 1.5 * sigma
    out[shock_mask] *= (1 + vol_shock)
    # Drift shift (negative = bearish bias)
    out += drift_shift / out.shape[1]
    # Correlation crush: add common factor shock
    if correlation_crush > 0:
        common = np.random.randn(out.shape[1]) * sigma * correlation_crush
        out += common[np.newaxis, :]
    return out


def simulate_portfolio_paths(scenarios: np.ndarray, initial_value: float = 100.0) -> np.ndarray:
    """Convert log-return scenarios to portfolio value paths."""
    cum_returns = np.cumsum(scenarios, axis=1)
    paths = initial_value * np.exp(cum_returns)
    return paths


def stress_correlation_matrix(corr_matrix: np.ndarray, regime: str) -> np.ndarray:
    """Apply regime-dependent correlation stress."""
    n = corr_matrix.shape[0]
    stressed = corr_matrix.copy()
    if regime == "crisis":
        stressed = corr_matrix * 0.3 + 0.7 * np.ones((n, n))
        np.fill_diagonal(stressed, 1.0)
    elif regime == "anti_correlation":
        stressed = -corr_matrix * 0.6
        np.fill_diagonal(stressed, 1.0)
        stressed = np.clip(stressed, -0.99, 0.99)
        np.fill_diagonal(stressed, 1.0)
    elif regime == "regime_switch":
        stressed = corr_matrix * 0.5
        stressed[0, 1:] = -0.3
        stressed[1:, 0] = -0.3
        np.fill_diagonal(stressed, 1.0)
    return stressed


def compute_risk_metrics(paths: np.ndarray, confidence: float = 0.95) -> dict:
    """Compute comprehensive risk metrics from simulation paths."""
    final_vals = paths[:, -1]
    initial = paths[:, 0].mean()

    returns_final = (final_vals - initial) / initial

    # VaR & CVaR
    var_level  = 1 - confidence
    var        = np.percentile(returns_final, var_level * 100)
    cvar_mask  = returns_final <= var
    cvar       = returns_final[cvar_mask].mean() if cvar_mask.sum() > 0 else var

    # Max drawdown per path
    peak       = np.maximum.accumulate(paths, axis=1)
    dd         = (paths - peak) / peak
    max_dd_per = dd.min(axis=1)
    max_dd     = max_dd_per.mean()
    worst_dd   = max_dd_per.min()

    # Tail ratio (upside/downside 10%)
    top10  = np.percentile(returns_final, 90)
    bot10  = np.percentile(returns_final, 10)
    tail_ratio = abs(top10 / bot10) if bot10 != 0 else np.nan

    return {
        "var":        float(var),
        "cvar":       float(cvar),
        "max_dd_avg": float(max_dd),
        "worst_dd":   float(worst_dd),
        "tail_ratio": float(tail_ratio),
        "skewness":   float(skew(returns_final)),
        "kurtosis":   float(kurtosis(returns_final)),
        "mean_return": float(returns_final.mean()),
        "std_return":  float(returns_final.std()),
        "p5":         float(np.percentile(final_vals, 5)),
        "p50":        float(np.percentile(final_vals, 50)),
        "p95":        float(np.percentile(final_vals, 95)),
    }


def find_worst_paths(paths: np.ndarray, n: int = 5) -> tuple:
    """Find worst, tail, and adversarial paths."""
    final = paths[:, -1]
    worst_idx    = np.argsort(final)[:n]
    best_idx     = np.argsort(final)[-n:]
    median_idx   = np.argsort(np.abs(final - np.median(final)))[:1]
    return paths[worst_idx], paths[best_idx], paths[median_idx]


# ─── PLOTLY THEME ───────────────────────────────────────────────────────────

PLOT_TEMPLATE = dict(
    layout=dict(
        font=dict(family="DM Sans, sans-serif", size=12, color="#0D1B2A"),
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(248,250,255,0.6)",
        margin=dict(l=20, r=20, t=40, b=20),
        xaxis=dict(showgrid=True, gridcolor="rgba(0,0,0,0.05)", gridwidth=1,
                   zeroline=False, linecolor="rgba(0,0,0,0.1)"),
        yaxis=dict(showgrid=True, gridcolor="rgba(0,0,0,0.05)", gridwidth=1,
                   zeroline=False, linecolor="rgba(0,0,0,0.1)"),
        legend=dict(bgcolor="rgba(255,255,255,0.85)", bordercolor="rgba(0,0,0,0.08)",
                    borderwidth=1, font=dict(size=11)),
    )
)

COLORS = {
    "blue":   "#1A56DB",
    "navy":   "#0F3460",
    "teal":   "#0EA5E9",
    "red":    "#DC2626",
    "amber":  "#D97706",
    "green":  "#059669",
    "purple": "#7C3AED",
    "gray":   "#6B7280",
}


def apply_theme(fig):
    fig.update_layout(**PLOT_TEMPLATE["layout"])
    return fig


# ─── SIDEBAR ────────────────────────────────────────────────────────────────

with st.sidebar:
    st.markdown("""
    <div style="padding: 4px 0 16px; border-bottom: 1px solid rgba(255,255,255,0.1); margin-bottom: 16px;">
        <div style="font-size: 11px; letter-spacing: 2px; text-transform: uppercase; opacity: 0.5; margin-bottom: 4px;">CONFIGURATION</div>
        <div style="font-size: 16px; font-weight: 700; opacity: 0.95;">Simulation Parameters</div>
    </div>
    """, unsafe_allow_html=True)

    st.markdown('<div style="font-size:11px;letter-spacing:1.5px;text-transform:uppercase;opacity:0.5;margin-bottom:6px;">ASSET UNIVERSE</div>', unsafe_allow_html=True)

    asset_class = st.selectbox("Asset Class", ["Equities", "Crypto", "Mixed"])

    EQUITY_DEFAULTS = ["AAPL", "MSFT", "GOOGL", "JPM", "XOM"]
    CRYPTO_DEFAULTS = ["BTC-USD", "ETH-USD", "SOL-USD"]
    MIXED_DEFAULTS  = ["AAPL", "MSFT", "BTC-USD", "GLD", "SPY"]

    default_map = {"Equities": EQUITY_DEFAULTS, "Crypto": CRYPTO_DEFAULTS, "Mixed": MIXED_DEFAULTS}

    tickers_input = st.text_input("Tickers (comma-separated)", value=", ".join(default_map[asset_class]))
    tickers = [t.strip().upper() for t in tickers_input.split(",") if t.strip()]

    data_period = st.selectbox("Historical Period", ["6mo", "1y", "2y", "5y"], index=2)

    st.markdown("---")
    st.markdown('<div style="font-size:11px;letter-spacing:1.5px;text-transform:uppercase;opacity:0.5;margin-bottom:6px;">MONTE CARLO</div>', unsafe_allow_html=True)

    n_simulations = st.select_slider("Simulations", options=[500, 1000, 5000, 10000, 25000, 50000], value=5000)
    horizon_days  = st.slider("Forecast Horizon (days)", 30, 252, 90)
    confidence    = st.slider("Confidence Level", 0.90, 0.99, 0.95, 0.01)

    st.markdown("---")
    st.markdown('<div style="font-size:11px;letter-spacing:1.5px;text-transform:uppercase;opacity:0.5;margin-bottom:6px;">GENERATIVE ENGINE</div>', unsafe_allow_html=True)

    gen_model     = st.selectbox("Scenario Model", ["VAE (Fat-Tail)", "Block Bootstrap", "Both (Ensemble)"])
    tail_amplify  = st.slider("Tail Amplification ×", 1.0, 3.0, 1.5, 0.1)
    block_size    = st.slider("Bootstrap Block Size", 5, 30, 10)

    st.markdown("---")
    st.markdown('<div style="font-size:11px;letter-spacing:1.5px;text-transform:uppercase;opacity:0.5;margin-bottom:6px;">ADVERSARIAL STRESS</div>', unsafe_allow_html=True)

    vol_shock      = st.slider("Volatility Shock", 0.0, 2.0, 0.5, 0.1)
    drift_shift    = st.slider("Drift Shift (bear bias)", -0.50, 0.0, -0.15, 0.01)
    corr_crush     = st.slider("Correlation Crush", 0.0, 1.0, 0.3, 0.05)
    corr_regime    = st.selectbox("Correlation Regime", ["normal", "crisis", "anti_correlation", "regime_switch"])

    st.markdown("---")
    st.markdown('<div style="font-size:11px;letter-spacing:1.5px;text-transform:uppercase;opacity:0.5;margin-bottom:6px;">WEIGHTS</div>', unsafe_allow_html=True)

    weight_mode = st.radio("Portfolio Weights", ["Equal Weight", "Custom"])
    custom_weights = {}
    if weight_mode == "Custom" and tickers:
        for t in tickers:
            custom_weights[t] = st.slider(f"{t} weight", 0.0, 1.0, 1.0/len(tickers), 0.05)

    st.markdown("---")
    run_btn = st.button("🚀  Run Stress Test", use_container_width=True)


# ─── MAIN CONTENT ───────────────────────────────────────────────────────────

# Hero
st.markdown("""
<div style="text-align:center; padding: 10px 0 30px;">
    <div style="font-size:11px;letter-spacing:3px;text-transform:uppercase;color:#1A56DB;font-weight:600;margin-bottom:10px;">INSTITUTIONAL RISK INTELLIGENCE</div>
    <h1 style="font-size:42px;font-weight:800;letter-spacing:-1.5px;color:#0D1B2A;margin:0 0 12px;">
        Aegis <span style="background:linear-gradient(135deg,#1A56DB,#7C3AED);-webkit-background-clip:text;-webkit-text-fill-color:transparent;">Stress Testing</span> Platform
    </h1>
    <p style="font-size:15px;color:#718096;max-width:600px;margin:0 auto;line-height:1.6;">
        Adversarial scenario generation · Tail risk quantification · Correlation breakdown simulation
    </p>
</div>
""", unsafe_allow_html=True)

# ─── DATA INGESTION ─────────────────────────────────────────────────────────
st.markdown("""
<div class="section-header">
    <div class="section-tag">MODULE 01</div>
    <div class="section-title">Data Ingestion & Market Intelligence</div>
    <div class="section-subtitle">Real-time quotes + historical training data via Yahoo Finance</div>
</div>
""", unsafe_allow_html=True)

with st.spinner("Fetching market data…"):
    prices = fetch_data(tickers, period=data_period)

if prices.empty:
    st.markdown('<div class="warn-box">⚠️ Could not fetch data for the specified tickers. Please check the symbols and try again.</div>', unsafe_allow_html=True)
    st.stop()

valid_tickers = list(prices.columns)
returns_df    = compute_returns(prices)

# Live quotes row
quote_cols = st.columns(min(len(valid_tickers), 6))
for i, tkr in enumerate(valid_tickers[:6]):
    q = fetch_live_quote(tkr)
    sign = "+" if q["change_pct"] >= 0 else ""
    badge_class = "badge-green" if q["change_pct"] >= 0 else "badge-red"
    arrow = "▲" if q["change_pct"] >= 0 else "▼"
    with quote_cols[i]:
        st.markdown(f"""
        <div class="kpi-card">
            <div class="kpi-label">{tkr}</div>
            <div class="kpi-value" style="font-size:22px;">${q['price']:,.2f}</div>
            <span class="kpi-badge {badge_class}">{arrow} {sign}{q['change_pct']:.2f}%</span>
        </div>
        """, unsafe_allow_html=True)

# Price chart
tab1, tab2 = st.tabs(["📈 Price History", "📊 Return Distribution"])

with tab1:
    fig_price = go.Figure()
    palette = [COLORS["blue"], COLORS["red"], COLORS["green"], COLORS["purple"], COLORS["amber"], COLORS["teal"]]
    norm_prices = prices / prices.iloc[0] * 100
    for i, tkr in enumerate(valid_tickers):
        fig_price.add_trace(go.Scatter(
            x=norm_prices.index, y=norm_prices[tkr],
            name=tkr, line=dict(width=1.8, color=palette[i % len(palette)]),
            mode="lines"
        ))
    fig_price.update_layout(title="Normalized Price Performance (Base=100)",
                             height=380, **PLOT_TEMPLATE["layout"])
    st.plotly_chart(fig_price, use_container_width=True)

with tab2:
    fig_dist = make_subplots(rows=1, cols=len(valid_tickers),
                              subplot_titles=valid_tickers[:6])
    for i, tkr in enumerate(valid_tickers[:6]):
        r = returns_df[tkr].dropna()
        fig_dist.add_trace(go.Histogram(
            x=r, name=tkr, nbinsx=60,
            marker_color=palette[i % len(palette)],
            marker_line_width=0, opacity=0.75
        ), row=1, col=i+1)
    fig_dist.update_layout(height=320, showlegend=False, **PLOT_TEMPLATE["layout"])
    st.plotly_chart(fig_dist, use_container_width=True)

# Regime detection
st.markdown("""
<div class="section-header" style="margin-top:32px;">
    <div class="section-tag">MODULE 02</div>
    <div class="section-title">Regime Detection Engine</div>
    <div class="section-subtitle">Volatility-clustering regime classification across the portfolio</div>
</div>
""", unsafe_allow_html=True)

regime_cols = st.columns(len(valid_tickers))
regime_color_map = {"Bull": "regime-bull", "Normal": "regime-normal", "Stress": "regime-stress", "Crisis": "regime-crisis"}

for i, tkr in enumerate(valid_tickers):
    r = returns_df[tkr].dropna()
    regimes = detect_regime(r)
    current_regime = regimes.iloc[-1] if not regimes.empty else "Unknown"
    rc = regime_color_map.get(current_regime, "regime-normal")
    ann_vol = r.std() * np.sqrt(252) * 100
    with regime_cols[i]:
        st.markdown(f"""
        <div class="kpi-card">
            <div class="kpi-label">{tkr} — Regime</div>
            <div style="margin:10px 0;"><span class="regime-badge {rc}">● {current_regime}</span></div>
            <div class="kpi-sub">Ann. Vol: <strong>{ann_vol:.1f}%</strong></div>
        </div>
        """, unsafe_allow_html=True)

# Regime timeline for first ticker
if len(valid_tickers) > 0:
    r0 = returns_df[valid_tickers[0]].dropna()
    regime_series = detect_regime(r0).dropna()
    reg_color_map = {"Bull": "#3B82F6", "Normal": "#059669", "Stress": "#D97706", "Crisis": "#DC2626"}
    regime_num = regime_series.map({"Bull": 0, "Normal": 1, "Stress": 2, "Crisis": 3})
    fig_regime = go.Figure()
    fig_regime.add_trace(go.Scatter(
        x=regime_series.index, y=regime_num,
        mode="lines", fill="tozeroy",
        line=dict(width=0),
        fillcolor="rgba(26,86,219,0.15)",
        name="Regime Level"
    ))
    fig_regime.update_layout(
        title=f"Regime Timeline — {valid_tickers[0]}",
        yaxis=dict(tickvals=[0,1,2,3], ticktext=["Bull","Normal","Stress","Crisis"]),
        height=220, **PLOT_TEMPLATE["layout"]
    )
    st.plotly_chart(fig_regime, use_container_width=True)


# ─── CORRELATION ENGINE ─────────────────────────────────────────────────────
st.markdown("""
<div class="section-header">
    <div class="section-tag">MODULE 03</div>
    <div class="section-title">Correlation Breakdown Engine</div>
    <div class="section-subtitle">Regime-switching correlation matrices and contagion simulation</div>
</div>
""", unsafe_allow_html=True)

if len(valid_tickers) >= 2:
    corr_raw = returns_df[valid_tickers].corr().values
    stressed_corr = stress_correlation_matrix(corr_raw, corr_regime)

    c1, c2 = st.columns(2)
    with c1:
        fig_corr1 = go.Figure(go.Heatmap(
            z=corr_raw, x=valid_tickers, y=valid_tickers,
            colorscale=[[0,"#DC2626"],[0.5,"#F3F4F6"],[1,"#1A56DB"]],
            zmin=-1, zmax=1,
            text=np.round(corr_raw,2), texttemplate="%{text}",
            colorbar=dict(len=0.8)
        ))
        fig_corr1.update_layout(title="Historical Correlation", height=360, **PLOT_TEMPLATE["layout"])
        st.plotly_chart(fig_corr1, use_container_width=True)

    with c2:
        fig_corr2 = go.Figure(go.Heatmap(
            z=stressed_corr, x=valid_tickers, y=valid_tickers,
            colorscale=[[0,"#DC2626"],[0.5,"#F3F4F6"],[1,"#1A56DB"]],
            zmin=-1, zmax=1,
            text=np.round(stressed_corr,2), texttemplate="%{text}",
            colorbar=dict(len=0.8)
        ))
        fig_corr2.update_layout(title=f"Stressed Correlation ({corr_regime.replace('_',' ').title()})",
                                 height=360, **PLOT_TEMPLATE["layout"])
        st.plotly_chart(fig_corr2, use_container_width=True)

    st.markdown(f"""
    <div class="info-box">
        <div class="info-box-title">CORRELATION STRESS ANALYSIS — {corr_regime.upper()}</div>
        <div class="info-box-text">
        Under the <strong>{corr_regime.replace('_',' ')}</strong> regime, asset correlations shift significantly.
        The average absolute correlation change is <strong>{np.abs(stressed_corr - corr_raw).mean():.3f}</strong>.
        This contagion effect amplifies portfolio losses beyond what individual asset VaR would suggest.
        </div>
    </div>
    """, unsafe_allow_html=True)
else:
    st.info("Add 2+ tickers to visualize correlation breakdown.")


# ─── GENERATIVE ENGINE + MONTE CARLO ────────────────────────────────────────
st.markdown("""
<div class="section-header">
    <div class="section-tag">MODULE 04 + 05</div>
    <div class="section-title">Generative Scenario Engine & Monte Carlo Simulation</div>
    <div class="section-subtitle">VAE fat-tail modeling · Block bootstrap · Adversarial perturbations</div>
</div>
""", unsafe_allow_html=True)

if not run_btn:
    st.markdown("""
    <div class="glass-panel" style="text-align:center;padding:48px 24px;">
        <div style="font-size:40px;margin-bottom:16px;">🎲</div>
        <div style="font-size:18px;font-weight:700;color:#0D1B2A;margin-bottom:8px;">Configure & Launch Simulation</div>
        <div style="font-size:14px;color:#718096;">Set your parameters in the sidebar and press <strong>Run Stress Test</strong> to begin adversarial simulation.</div>
    </div>
    """, unsafe_allow_html=True)
else:
    # ── Compute portfolio returns ──────────────────────────────────────────
    with st.spinner("Generating scenarios and running simulations…"):
        # Portfolio weights
        n = len(valid_tickers)
        if weight_mode == "Custom" and custom_weights:
            wts = np.array([custom_weights.get(t, 1/n) for t in valid_tickers])
            total = wts.sum()
            wts = wts / total if total > 0 else np.ones(n)/n
        else:
            wts = np.ones(n) / n

        port_returns = (returns_df[valid_tickers] * wts).sum(axis=1).dropna().values

        # Generate scenarios
        half = n_simulations // 2
        if gen_model == "VAE (Fat-Tail)":
            raw_scenarios = vae_generate(port_returns, n_simulations, horizon_days, tail_amplify)
        elif gen_model == "Block Bootstrap":
            raw_scenarios = block_bootstrap(port_returns, n_simulations, horizon_days, block_size)
        else:  # Ensemble
            s1 = vae_generate(port_returns, half, horizon_days, tail_amplify)
            s2 = block_bootstrap(port_returns, n_simulations - half, horizon_days, block_size)
            raw_scenarios = np.vstack([s1, s2])

        # Adversarial perturbations
        adv_scenarios = apply_adversarial_perturbations(raw_scenarios, vol_shock, drift_shift, corr_crush)

        # Portfolio paths
        paths = simulate_portfolio_paths(adv_scenarios, initial_value=100.0)

        # Worst / best paths
        worst_paths, best_paths, median_path = find_worst_paths(paths)

        # Risk metrics
        metrics = compute_risk_metrics(paths, confidence)

    # ── KPI Bar ───────────────────────────────────────────────────────────
    st.markdown('<div class="kpi-grid">', unsafe_allow_html=True)
    kpi_data = [
        ("VALUE AT RISK", f"{metrics['var']*100:.2f}%", f"{int(confidence*100)}% confidence", "badge-red"),
        ("CVaR / ES",      f"{metrics['cvar']*100:.2f}%", "Expected shortfall", "badge-red"),
        ("MAX DRAWDOWN",   f"{metrics['worst_dd']*100:.2f}%", "Worst path", "badge-amber"),
        ("TAIL RATIO",     f"{metrics['tail_ratio']:.3f}", "Upside/Downside", "badge-blue"),
        ("EXCESS KURTOSIS",f"{metrics['kurtosis']:.2f}", "Fat-tail indicator", "badge-amber"),
        ("SKEWNESS",       f"{metrics['skewness']:.3f}", "Return asymmetry", "badge-blue"),
        ("P5 VALUE",       f"${metrics['p5']:.1f}", "5th percentile portfolio", "badge-red"),
        ("P95 VALUE",      f"${metrics['p95']:.1f}", "95th percentile portfolio", "badge-green"),
    ]
    kpi_html = '<div class="kpi-grid">'
    for label, val, sub, badge in kpi_data:
        kpi_html += f"""
        <div class="kpi-card">
            <div class="kpi-label">{label}</div>
            <div class="kpi-value" style="font-size:24px;">{val}</div>
            <div class="kpi-sub">{sub}</div>
        </div>
        """
    kpi_html += '</div>'
    st.markdown(kpi_html, unsafe_allow_html=True)

    # ── Simulation Tabs ───────────────────────────────────────────────────
    sim_tab1, sim_tab2, sim_tab3, sim_tab4 = st.tabs([
        "🌐 Path Simulation", "🔥 Tail Distribution", "📉 Drawdown Analysis", "📦 3D Surface"
    ])

    with sim_tab1:
        fig_paths = go.Figure()
        # Fan: sample 200 random paths lightly
        sample_idx = np.random.choice(paths.shape[0], min(200, paths.shape[0]), replace=False)
        for idx in sample_idx:
            fig_paths.add_trace(go.Scatter(
                x=list(range(horizon_days)), y=paths[idx],
                mode="lines", line=dict(width=0.4, color="rgba(26,86,219,0.08)"),
                showlegend=False, hoverinfo="skip"
            ))
        # Percentile bands
        p5  = np.percentile(paths, 5,  axis=0)
        p25 = np.percentile(paths, 25, axis=0)
        p50 = np.percentile(paths, 50, axis=0)
        p75 = np.percentile(paths, 75, axis=0)
        p95 = np.percentile(paths, 95, axis=0)
        x   = list(range(horizon_days))

        fig_paths.add_trace(go.Scatter(x=x+x[::-1], y=list(p95)+list(p5[::-1]),
            fill="toself", fillcolor="rgba(26,86,219,0.05)", line_color="transparent",
            name="5–95% band", showlegend=True))
        fig_paths.add_trace(go.Scatter(x=x+x[::-1], y=list(p75)+list(p25[::-1]),
            fill="toself", fillcolor="rgba(26,86,219,0.10)", line_color="transparent",
            name="25–75% band", showlegend=True))

        fig_paths.add_trace(go.Scatter(x=x, y=p50, name="Median",
            line=dict(color=COLORS["blue"], width=2.5)))
        for wp in worst_paths[:3]:
            fig_paths.add_trace(go.Scatter(x=x, y=wp, name="Worst path",
                line=dict(color=COLORS["red"], width=1.5, dash="dot"), showlegend=False))
        for bp in best_paths[:2]:
            fig_paths.add_trace(go.Scatter(x=x, y=bp, name="Best path",
                line=dict(color=COLORS["green"], width=1.5, dash="dot"), showlegend=False))

        fig_paths.update_layout(
            title=f"Portfolio Simulation — {n_simulations:,} Paths | {horizon_days}d Horizon",
            xaxis_title="Trading Days", yaxis_title="Portfolio Value (Base=100)",
            height=480, **PLOT_TEMPLATE["layout"]
        )
        st.plotly_chart(fig_paths, use_container_width=True)

        # Adversarial worst path highlight
        worst_single = worst_paths[0]
        worst_drawdown = (worst_single - worst_single.max()) / worst_single.max()
        st.markdown(f"""
        <div class="warn-box">
            ⚡ <strong>Adversarial Worst Path:</strong> This path reaches a maximum loss of
            <strong>{worst_single[-1]-100:.1f}%</strong> by day {horizon_days},
            with a peak drawdown of <strong>{worst_drawdown.min()*100:.1f}%</strong>.
            Tail amplification factor: <strong>{tail_amplify}×</strong>.
        </div>
        """, unsafe_allow_html=True)

    with sim_tab2:
        final_vals = paths[:, -1]
        returns_final = (final_vals - 100) / 100

        fig_tail = go.Figure()
        fig_tail.add_trace(go.Histogram(
            x=returns_final, nbinsx=120, name="Simulated Returns",
            marker_color=COLORS["blue"], opacity=0.6,
            histnorm="probability density"
        ))
        # Normal overlay
        mu_s = returns_final.mean()
        sg_s = returns_final.std()
        x_norm = np.linspace(returns_final.min(), returns_final.max(), 300)
        y_norm = norm.pdf(x_norm, mu_s, sg_s)
        fig_tail.add_trace(go.Scatter(x=x_norm, y=y_norm, name="Normal Dist.",
            line=dict(color=COLORS["gray"], width=2, dash="dash")))
        # VaR / CVaR lines
        fig_tail.add_vline(x=metrics["var"], line_color=COLORS["amber"],
            line_dash="dash", annotation_text=f"VaR {int(confidence*100)}%",
            annotation_position="top right")
        fig_tail.add_vline(x=metrics["cvar"], line_color=COLORS["red"],
            line_dash="dot", annotation_text="CVaR",
            annotation_position="top right")

        fig_tail.update_layout(
            title="Return Distribution — Tail Risk Analysis",
            xaxis_title="Portfolio Return", yaxis_title="Density",
            height=420, **PLOT_TEMPLATE["layout"]
        )
        st.plotly_chart(fig_tail, use_container_width=True)

        # QQ plot
        fig_qq = go.Figure()
        sorted_r = np.sort(returns_final)
        theoretical_q = norm.ppf(np.linspace(0.01, 0.99, len(sorted_r)))
        fig_qq.add_trace(go.Scatter(x=theoretical_q, y=sorted_r[:len(theoretical_q)],
            mode="markers", marker=dict(size=3, color=COLORS["blue"], opacity=0.4),
            name="Empirical vs Normal"))
        fig_qq.add_trace(go.Scatter(x=[-4,4], y=[-4*sg_s+mu_s, 4*sg_s+mu_s],
            mode="lines", line=dict(color=COLORS["red"], width=2), name="Normal Line"))
        fig_qq.update_layout(title="QQ Plot — Tail Departure from Normality",
            xaxis_title="Theoretical Quantiles", yaxis_title="Empirical Quantiles",
            height=360, **PLOT_TEMPLATE["layout"])
        st.plotly_chart(fig_qq, use_container_width=True)

    with sim_tab3:
        # Drawdown waterfall for worst path
        worst_p = worst_paths[0]
        roll_max = np.maximum.accumulate(worst_p)
        drawdown = (worst_p - roll_max) / roll_max * 100
        x = list(range(horizon_days))

        fig_dd = make_subplots(rows=2, cols=1, shared_xaxes=True,
                                row_heights=[0.6, 0.4],
                                subplot_titles=["Adversarial Worst Path", "Drawdown (%)"])
        fig_dd.add_trace(go.Scatter(x=x, y=worst_p, name="Portfolio Value",
            line=dict(color=COLORS["navy"], width=2)), row=1, col=1)
        fig_dd.add_trace(go.Scatter(x=x, y=list(roll_max), name="Peak",
            line=dict(color=COLORS["blue"], width=1.5, dash="dot")), row=1, col=1)
        fig_dd.add_trace(go.Scatter(x=x, y=drawdown, name="Drawdown",
            fill="tozeroy", fillcolor="rgba(220,38,38,0.15)",
            line=dict(color=COLORS["red"], width=1.5)), row=2, col=1)

        fig_dd.update_layout(height=480, **PLOT_TEMPLATE["layout"])
        st.plotly_chart(fig_dd, use_container_width=True)

        # Drawdown histogram across all paths
        peak_all = np.maximum.accumulate(paths, axis=1)
        dd_all   = ((paths - peak_all) / peak_all).min(axis=1) * 100
        fig_dd_hist = go.Figure()
        fig_dd_hist.add_trace(go.Histogram(x=dd_all, nbinsx=80,
            marker_color=COLORS["red"], opacity=0.7, name="Max Drawdown Dist."))
        fig_dd_hist.add_vline(x=dd_all.mean(), line_color=COLORS["navy"],
            annotation_text=f"Avg: {dd_all.mean():.1f}%")
        fig_dd_hist.update_layout(title="Maximum Drawdown Distribution Across All Paths",
            xaxis_title="Max Drawdown (%)", yaxis_title="Count",
            height=300, **PLOT_TEMPLATE["layout"])
        st.plotly_chart(fig_dd_hist, use_container_width=True)

    with sim_tab4:
        # 3D surface: Time × Percentile × Portfolio Value
        n_time   = min(horizon_days, 60)
        t_idx    = np.linspace(0, horizon_days-1, n_time, dtype=int)
        pct_range = np.arange(1, 100, 2)
        Z = np.array([[np.percentile(paths[:, t], p) for t in t_idx] for p in pct_range])

        fig_3d = go.Figure(go.Surface(
            x=t_idx, y=pct_range, z=Z,
            colorscale=[
                [0.0, "#DC2626"], [0.25, "#D97706"],
                [0.5, "#F3F4F6"], [0.75, "#1A56DB"], [1.0, "#059669"]
            ],
            contours=dict(
                x=dict(show=True, color="rgba(0,0,0,0.1)"),
                y=dict(show=True, color="rgba(0,0,0,0.1)")
            ),
            opacity=0.92
        ))
        fig_3d.update_layout(
            title="3D Risk Surface — Time × Percentile × Portfolio Value",
            scene=dict(
                xaxis_title="Day",
                yaxis_title="Percentile",
                zaxis_title="Portfolio Value",
                bgcolor="rgba(248,250,255,0.8)",
                xaxis=dict(gridcolor="rgba(0,0,0,0.05)"),
                yaxis=dict(gridcolor="rgba(0,0,0,0.05)"),
                zaxis=dict(gridcolor="rgba(0,0,0,0.05)"),
            ),
            height=560,
            paper_bgcolor="rgba(0,0,0,0)",
            font=dict(family="DM Sans", size=11),
            margin=dict(l=10, r=10, t=50, b=10)
        )
        st.plotly_chart(fig_3d, use_container_width=True)


    # ─── RISK METRICS TABLE ─────────────────────────────────────────────────
    st.markdown("""
    <div class="section-header">
        <div class="section-tag">MODULE 06</div>
        <div class="section-title">Risk & Tail Analytics</div>
        <div class="section-subtitle">Professional-grade metric suite with statistical decomposition</div>
    </div>
    """, unsafe_allow_html=True)

    col_a, col_b = st.columns(2)

    with col_a:
        st.markdown('<div class="glass-panel">', unsafe_allow_html=True)
        st.markdown("**📐 Core Risk Metrics**")
        metric_table_html = """
        <table class="styled-table">
        <thead><tr><th>Metric</th><th>Value</th><th>Signal</th></tr></thead>
        <tbody>
        """
        def signal(val, thresholds, labels, is_pct=True):
            formatted = f"{val*100:.2f}%" if is_pct else f"{val:.4f}"
            for threshold, label in zip(thresholds, labels):
                if val < threshold:
                    color = {"🔴 High Risk": "#DC2626", "🟡 Moderate": "#D97706", "🟢 Low": "#059669"}.get(label, "#718096")
                    return formatted, f'<span style="color:{color};font-size:11px;font-weight:600;">{label}</span>'
            return formatted, '<span style="color:#059669;font-size:11px;">🟢 Low</span>'

        rows = [
            ("Value at Risk (VaR)", metrics["var"], [-0.10, -0.05, 0], [-.10,-.05], ["🔴 High Risk","🟡 Moderate","🟢 Low"]),
            ("CVaR / Expected Shortfall", metrics["cvar"], [-0.15, -0.08, 0], [-.15,-.08], ["🔴 Severe","🟡 Elevated","🟢 Normal"]),
            ("Avg Max Drawdown", metrics["max_dd_avg"], [-0.20, -0.10, 0], [-.20,-.10], ["🔴 Severe","🟡 Moderate","🟢 Mild"]),
            ("Worst Drawdown", metrics["worst_dd"], [-0.30, -0.15, 0], [-.30,-.15], ["🔴 Catastrophic","🟡 Severe","🟢 Moderate"]),
        ]
        for label, val, _, thresholds, labels in rows:
            fmt_val = f"{val*100:.2f}%"
            metric_table_html += f"<tr><td>{label}</td><td><strong>{fmt_val}</strong></td><td>"
            if val < thresholds[0]:
                metric_table_html += f'<span style="color:#DC2626;font-size:11px;font-weight:600;">{labels[0]}</span>'
            elif val < thresholds[1]:
                metric_table_html += f'<span style="color:#D97706;font-size:11px;font-weight:600;">{labels[1]}</span>'
            else:
                metric_table_html += f'<span style="color:#059669;font-size:11px;font-weight:600;">{labels[2]}</span>'
            metric_table_html += "</td></tr>"

        metric_table_html += "</tbody></table>"
        st.markdown(metric_table_html, unsafe_allow_html=True)
        st.markdown("</div>", unsafe_allow_html=True)

    with col_b:
        st.markdown('<div class="glass-panel">', unsafe_allow_html=True)
        st.markdown("**📊 Distribution Statistics**")
        stat_table_html = """
        <table class="styled-table">
        <thead><tr><th>Statistic</th><th>Value</th><th>Interpretation</th></tr></thead>
        <tbody>
        """
        stat_rows = [
            ("Skewness",         f"{metrics['skewness']:.4f}",   "Negative → left-tail risk"),
            ("Excess Kurtosis",  f"{metrics['kurtosis']:.4f}",   ">3 → fat-tailed distribution"),
            ("Mean Return",      f"{metrics['mean_return']*100:.3f}%", "Expected path outcome"),
            ("Std Deviation",    f"{metrics['std_return']*100:.3f}%", "Return dispersion"),
            ("Tail Ratio",       f"{metrics['tail_ratio']:.4f}", "Upside vs downside asymmetry"),
            ("P5 Portfolio",     f"${metrics['p5']:.2f}", "5th percentile outcome"),
            ("P50 Portfolio",    f"${metrics['p50']:.2f}", "Median outcome"),
            ("P95 Portfolio",    f"${metrics['p95']:.2f}", "95th percentile outcome"),
        ]
        for label, val, interp in stat_rows:
            stat_table_html += f"<tr><td>{label}</td><td><strong>{val}</strong></td><td style='color:#718096;font-size:11px;'>{interp}</td></tr>"
        stat_table_html += "</tbody></table>"
        st.markdown(stat_table_html, unsafe_allow_html=True)
        st.markdown("</div>", unsafe_allow_html=True)

    # ── Per-Asset Risk ──────────────────────────────────────────────────────
    with st.expander("📋 Per-Asset Risk Breakdown"):
        asset_metrics = []
        for tkr in valid_tickers:
            r = returns_df[tkr].dropna().values
            ann_vol = np.std(r) * np.sqrt(252)
            var_95  = np.percentile(r, 5)
            mdd     = (prices[tkr] / prices[tkr].cummax() - 1).min()
            asset_metrics.append({
                "Ticker": tkr,
                "Ann. Vol": f"{ann_vol*100:.2f}%",
                "Daily VaR (95%)": f"{var_95*100:.3f}%",
                "Historical MDD": f"{mdd*100:.2f}%",
                "Skew": f"{skew(r):.3f}",
                "Kurt": f"{kurtosis(r):.3f}",
                "Weight": f"{wts[valid_tickers.index(tkr)]*100:.1f}%" if tkr in valid_tickers else "—"
            })
        st.dataframe(pd.DataFrame(asset_metrics), use_container_width=True, hide_index=True)


    # ─── SCENARIO COMPARISON ────────────────────────────────────────────────
    st.markdown("""
    <div class="section-header">
        <div class="section-tag">MODULE 07</div>
        <div class="section-title">Scenario Comparison Dashboard</div>
        <div class="section-subtitle">Normal vs stressed vs adversarial path comparison</div>
    </div>
    """, unsafe_allow_html=True)

    # Re-run clean (no adversarial) for comparison
    clean_scenarios = vae_generate(port_returns, 2000, horizon_days, 1.0)
    clean_paths = simulate_portfolio_paths(clean_scenarios)

    fig_cmp = go.Figure()
    for label, p_arr, color in [
        ("Normal Scenario (P50)", np.percentile(clean_paths, 50, axis=0), COLORS["green"]),
        ("Normal Scenario (P5)", np.percentile(clean_paths, 5, axis=0), COLORS["teal"]),
        ("Adversarial (P50)", np.percentile(paths, 50, axis=0), COLORS["blue"]),
        ("Adversarial (P5)", np.percentile(paths, 5, axis=0), COLORS["amber"]),
        ("Adversarial (P1)", np.percentile(paths, 1, axis=0), COLORS["red"]),
    ]:
        fig_cmp.add_trace(go.Scatter(
            x=list(range(horizon_days)), y=p_arr, name=label,
            line=dict(color=color, width=2)
        ))
    fig_cmp.update_layout(
        title="Scenario Comparison: Normal vs Adversarial Stress",
        xaxis_title="Days", yaxis_title="Portfolio Value",
        height=420, **PLOT_TEMPLATE["layout"]
    )
    st.plotly_chart(fig_cmp, use_container_width=True)


    # ─── EXPORT ─────────────────────────────────────────────────────────────
    st.markdown("""
    <div class="section-header">
        <div class="section-tag">MODULE 08</div>
        <div class="section-title">Export & Reporting</div>
        <div class="section-subtitle">Download simulation results and risk metrics</div>
    </div>
    """, unsafe_allow_html=True)

    export_col1, export_col2 = st.columns(2)
    with export_col1:
        # Export paths summary
        pct_df = pd.DataFrame({
            "Day": range(horizon_days),
            "P1":  np.percentile(paths, 1,  axis=0),
            "P5":  np.percentile(paths, 5,  axis=0),
            "P25": np.percentile(paths, 25, axis=0),
            "P50": np.percentile(paths, 50, axis=0),
            "P75": np.percentile(paths, 75, axis=0),
            "P95": np.percentile(paths, 95, axis=0),
            "P99": np.percentile(paths, 99, axis=0),
        })
        csv_paths = pct_df.to_csv(index=False)
        st.download_button(
            "⬇️ Download Path Percentiles (CSV)",
            data=csv_paths,
            file_name=f"aegis_paths_{datetime.now().strftime('%Y%m%d_%H%M')}.csv",
            mime="text/csv",
            use_container_width=True
        )

    with export_col2:
        # Export risk metrics
        metrics_df = pd.DataFrame([{
            "Metric": k, "Value": v
        } for k, v in metrics.items()])
        csv_metrics = metrics_df.to_csv(index=False)
        st.download_button(
            "⬇️ Download Risk Metrics (CSV)",
            data=csv_metrics,
            file_name=f"aegis_metrics_{datetime.now().strftime('%Y%m%d_%H%M')}.csv",
            mime="text/csv",
            use_container_width=True
        )

    st.markdown("""
    <div class="info-box">
        <div class="info-box-title">SIMULATION SUMMARY</div>
        <div class="info-box-text">
        Simulation complete. <strong>%d paths</strong> generated over <strong>%d trading days</strong>
        using <strong>%s</strong> with adversarial perturbations applied.
        Correlation regime: <strong>%s</strong>. Tail amplification: <strong>%.1f×</strong>.
        </div>
    </div>
    """ % (n_simulations, horizon_days, gen_model, corr_regime, tail_amplify), unsafe_allow_html=True)


# ─── FOOTER ─────────────────────────────────────────────────────────────────
st.markdown(f"""
<div class="aegis-footer">
    <div class="aegis-footer-brand">🛡️ Aegis Risk Lab</div>
    <div style="font-size:12px;color:#718096;margin-bottom:8px;">
        Adversarial Stress Testing &amp; Tail Risk Intelligence Platform
    </div>
    <div style="width:60px;height:1px;background:linear-gradient(90deg,transparent,#CBD5E0,transparent);margin:12px auto;"></div>
    <div class="aegis-footer-made">Made by <strong>Sourish Dey</strong></div>
    <div style="font-size:11px;color:#A0AEC0;margin-top:6px;">
        Powered by Yahoo Finance · NumPy · Plotly · Streamlit &nbsp;|&nbsp; {datetime.now().year}
    </div>
</div>
""", unsafe_allow_html=True)
